#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>

class Flight {
private:
    std::string flight_number;
    std::string origin;
    std::string destination;
    int total_seats;
    int available_seats;
    std::vector<bool> seat_map;

public:
    Flight(const std::string& flight_number, const std::string& origin, const std::string& destination, int seats)
        : flight_number(flight_number), origin(origin), destination(destination), total_seats(seats), available_seats(seats), seat_map(seats, true) {}

    void display_info() const {
        std::cout << "Flight Number: " << flight_number << std::endl;
        std::cout << "Origin: " << origin << std::endl;
        std::cout << "Destination: " << destination << std::endl;
        std::cout << "Available Seats: " << available_seats << std::endl;
    }

    bool book_seat(int seat_number) {
        if (seat_number >= 0 && seat_number < total_seats && seat_map[seat_number]) {
            seat_map[seat_number] = false;
            --available_seats;
            return true;
        }
        return false;
    }

    void cancel_seat(int seat_number) {
        if (seat_number >= 0 && seat_number < total_seats && !seat_map[seat_number]) {
            seat_map[seat_number] = true;
            ++available_seats;
        }
    }

    bool is_seat_available(int seat_number) const {
        return seat_number >= 0 && seat_number < total_seats && seat_map[seat_number];
    }

    int get_total_seats() const { return total_seats; }
    int get_available_seats() const { return available_seats; }
    std::string get_flight_number() const { return flight_number; }
};

class Passenger {
private:
    std::string name;
    int booking_id;
    int seat_number;

public:
    Passenger(const std::string& name, int booking_id, int seat_number)
        : name(name), booking_id(booking_id), seat_number(seat_number) {}

    void display_info() const {
        std::cout << "Passenger Name: " << name << std::endl;
        std::cout << "Booking ID: " << booking_id << std::endl;
        std::cout << "Seat Number: " << seat_number << std::endl;
    }

    int get_booking_id() const { return booking_id; }
    int get_seat_number() const { return seat_number; }
    std::string get_name() const { return name; }
};

class Booking {
private:
    std::vector<Passenger> passengers;
    Flight& flight;

public:
    Booking(Flight& flight) : flight(flight) {}

    bool book_ticket(const std::string& name, int booking_id) {
        int seat_number = -1;
        for (int i = 0; i < flight.get_total_seats(); ++i) {
            if (flight.is_seat_available(i)) {
                seat_number = i;
                break;
            }
        }

        if (seat_number != -1 && flight.book_seat(seat_number)) {
            passengers.emplace_back(name, booking_id, seat_number);
            return true;
        }
        return false;
    }

    void cancel_ticket(int booking_id) {
        auto it = std::remove_if(passengers.begin(), passengers.end(),
            [booking_id](const Passenger& p) { return p.get_booking_id() == booking_id; });

        if (it != passengers.end()) {
            int seat_number = it->get_seat_number();
            flight.cancel_seat(seat_number);
            passengers.erase(it, passengers.end());
        }
    }

    void display_bookings() const {
        std::cout << "Booked Passengers:" << std::endl;
        for (const auto& passenger : passengers) {
            passenger.display_info();
        }
    }

    void generate_boarding_pass(int booking_id) const {
        auto it = std::find_if(passengers.begin(), passengers.end(),
            [booking_id](const Passenger& p) { return p.get_booking_id() == booking_id; });

        if (it != passengers.end()) {
            std::cout << "Boarding Pass:" << std::endl;
            std::cout << "=============================" << std::endl;
            std::cout << "Flight Number: " << flight.get_flight_number() << std::endl;
            std::cout << "Passenger Name: " << it->get_name() << std::endl;
            std::cout << "Seat Number: " << it->get_seat_number() << std::endl;
            std::cout << "=============================" << std::endl;
        } else {
            std::cout << "Booking ID not found!" << std::endl;
        }
    }
};

void display_flight_options(const std::vector<Flight>& flights) {
    std::cout << "Available Flights:" << std::endl;
    for (size_t i = 0; i < flights.size(); ++i) {
        std::cout << i + 1 << ". ";
        flights[i].display_info();
        std::cout << std::endl;
    }
}

int main() {
    std::vector<Flight> flights = {
        Flight("FL123", "New York", "Los Angeles", 10),
        Flight("FL456", "Chicago", "Miami", 5),
        Flight("FL789", "San Francisco", "Seattle", 8)
    };

    while (true) {
        std::cout << "Flight Booking System" << std::endl;
        std::cout << "1. Search Flights" << std::endl;
        std::cout << "2. Book Ticket" << std::endl;
        std::cout << "3. Cancel Booking" << std::endl;
        std::cout << "4. Generate Boarding Pass" << std::endl;
        std::cout << "5. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        
        int choice;
        std::cin >> choice;
        std::cin.ignore();  // To ignore the newline character left in the buffer

        switch (choice) {
            case 1: {
                display_flight_options(flights);
                break;
            }
            case 2: {
                display_flight_options(flights);
                std::cout << "Select flight (1-" << flights.size() << "): ";
                int flight_choice;
                std::cin >> flight_choice;
                std::cin.ignore();  // To ignore the newline character left in the buffer

                if (flight_choice >= 1 && flight_choice <= flights.size()) {
                    Flight& selected_flight = flights[flight_choice - 1];
                    std::string name;
                    int booking_id;
                    std::cout << "Enter Passenger Name: ";
                    std::getline(std::cin, name);
                    std::cout << "Enter Booking ID: ";
                    std::cin >> booking_id;

                    Booking booking(selected_flight);
                    if (booking.book_ticket(name, booking_id)) {
                        std::cout << "Booking successful!" << std::endl;
                    } else {
                        std::cout << "Booking failed. No available seats." << std::endl;
                    }
                } else {
                    std::cout << "Invalid flight selection." << std::endl;
                }
                break;
            }
            case 3: {
                display_flight_options(flights);
                std::cout << "Select flight (1-" << flights.size() << "): ";
                int flight_choice;
                std::cin >> flight_choice;
                std::cin.ignore();  // To ignore the newline character left in the buffer

                if (flight_choice >= 1 && flight_choice <= flights.size()) {
                    Flight& selected_flight = flights[flight_choice - 1];
                    int booking_id;
                    std::cout << "Enter Booking ID to cancel: ";
                    std::cin >> booking_id;

                    Booking booking(selected_flight);
                    booking.cancel_ticket(booking_id);
                    std::cout << "Booking canceled." << std::endl;
                } else {
                    std::cout << "Invalid flight selection." << std::endl;
                }
                break;
            }
            case 4: {
                display_flight_options(flights);
                std::cout << "Select flight (1-" << flights.size() << "): ";
                int flight_choice;
                std::cin >> flight_choice;
                std::cin.ignore();  // To ignore the newline character left in the buffer

                if (flight_choice >= 1 && flight_choice <= flights.size()) {
                    Flight& selected_flight = flights[flight_choice - 1];
                    int booking_id;
                    std::cout << "Enter Booking ID to generate boarding pass: ";
                    std::cin >> booking_id;

                    Booking booking(selected_flight);
                    booking.generate_boarding_pass(booking_id);
                } else {
                    std::cout << "Invalid flight selection." << std::endl;
                }
                break;
            }
            case 5: {
                std::cout << "Exiting..." << std::endl;
                return 0;
            }
            default: {
                std::cout << "Invalid choice. Please try again." << std::endl;
                break;
            }
        }
    }
}

